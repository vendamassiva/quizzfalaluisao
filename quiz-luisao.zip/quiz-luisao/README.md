# Quiz de Pré-qualificação — Luisão

Quiz de 5 perguntas para qualificação de leads, com barra de progresso e redirecionamento para formulário de captura.

## Estrutura

```
quiz-luisao/
├── index.html     # Estrutura da página
├── style.css      # Estilos (paleta dark, azul/prata/preto)
├── quiz.js        # Lógica das perguntas e navegação
├── vercel.json    # Configuração do deploy
└── README.md
```

## Deploy no GitHub + Vercel

### 1. Subir no GitHub

```bash
# Dentro da pasta quiz-luisao
git init
git add .
git commit -m "feat: quiz de pre-qualificacao"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/quiz-luisao.git
git push -u origin main
```

### 2. Deploy na Vercel

1. Acesse [vercel.com](https://vercel.com) e faça login
2. Clique em **Add New → Project**
3. Importe o repositório `quiz-luisao` do GitHub
4. Nas configurações, deixe tudo padrão (projeto é HTML puro)
5. Clique em **Deploy**

Pronto — a Vercel detecta automaticamente projetos HTML estáticos.

### Atualizar depois

Qualquer `git push` na branch `main` faz redeploy automático.

## Personalização

Para alterar o link do formulário, edite a variável no topo de `quiz.js`:

```js
const FORM_URL = 'https://form.respondi.app/RuLAddBp';
```
